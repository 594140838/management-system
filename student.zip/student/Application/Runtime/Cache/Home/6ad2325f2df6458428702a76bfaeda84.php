<?php if (!defined('THINK_PATH')) exit();?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="A layout example that shows off a blog page with a list of posts.">

    <title>Blog</title>

    


<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/grids-responsive-min.css">
<link rel="stylesheet" href="/student/Public/<?php echo (MODULE_NAME); ?>/Css/blog.css">

</head>
<body>







<div id="layout" class="pure-g">
    <div class="sidebar pure-u-1 pure-u-md-1-4">
        <div class="header">
            <h1 class="brand-title">朱星滔 的 学生管理系统</h1>
            <h2 class="brand-tagline">Welcome <?php echo session('username');?> to here</h2>


           <nav class="nav">
                <ul class="nav-list">
                    <?php if((session('username'))): ?><li class="nav-item">
                            <a class="pure-button" href="<?php echo U('Index/logout');?>">注销</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="pure-button" href="<?php echo U('Index/login');?>">登陆</a>
                        </li><?php endif; ?>
                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/register');?>">注册</a>
                    </li>
                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/index');?>">首页</a>
                    </li>
                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/manage');?>">管理</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

    <div class="content pure-u-1 pure-u-md-3-4">
        <div>
            <div class="posts">
                <h1 class="content-subhead">信息管理</h1>
                <section class="post">
                    <header class="post-header">
                        <h2 class="post-title">班级学生信息管理</h2>
                    </header>

                    <table border='1px' >
                    <tr width="600px">
                      <td>学号</td>
                      <td>名字</td>
                      <td>分数</td>
                      <td>院系</td>
                      <td>班级</td>
                      <td>编辑</td>
                   </tr>
            
                    <?php if(is_array($student)): $i = 0; $__LIST__ = $student;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$i): $mod = ($i % 2 );++$i;?><tr>           
                       <td> <input  type="text"  name ="sno"  value="<?php echo ($i["sno"]); ?>"></td>
                       <td> <input  type="text"  name="name"  value="<?php echo ($i["name"]); ?>"></td>
                       <td> <input  type="text"  name="grade" value="<?php echo ($i['grade']); ?>"></td>
                       <td> <input  type="text"  name="dept"  value="<?php echo ($i['dept']); ?>"></td>
                       <td> <input  type="text"  name="class" value="<?php echo ($i['class']); ?>"></td>   
                       <td>修改</td>
                       </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                    </table>
                    <input type ="submit" value="保存修改">
                </section>

            </div>

              
            

            <div class="footer">
                <div class="pure-menu pure-menu-horizontal">
                    <ul>
                        <li class="pure-menu-item"><a href="" class="pure-menu-link">About</a></li>
                        <li class="pure-menu-item"><a href="" class="pure-menu-link">Weibo</a></li>
                        <li class="pure-menu-item"><a href="" class="pure-menu-link">GitHub</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>


</body>
</html>