<?php if (!defined('THINK_PATH')) exit();?><html>
<?php echo ($info); ?>
</html>