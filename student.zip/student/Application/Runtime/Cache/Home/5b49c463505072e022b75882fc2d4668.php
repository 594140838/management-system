<?php if (!defined('THINK_PATH')) exit();?> <head>

<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/grids-responsive-min.css">
<link rel="stylesheet" href="/student/Public/<?php echo (MODULE_NAME); ?>/Css/blog.css">
 </head>
 <body>
 <div id="layout" class="pure-g">
    <div class="sidebar pure-u-1 pure-u-md-1-4">
        <div class="header">
            <h1 class="brand-title">朱星滔 的 学生管理系统</h1>
            <h2 class="brand-tagline">Welcome <?php echo session('username');?> to here</h2>

            <nav class="nav">
                <ul class="nav-list">
                    
                    
                    <?php if((session('username'))): ?><li class="nav-item">
                            <a class="pure-button" href="<?php echo U('Index/logout');?>">注销</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="pure-button" href="<?php echo U('Index/login');?>">登陆</a>
                        </li><?php endif; ?>

                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/register');?>">注册</a>
                    </li>
                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/index');?>">首页</a>
                    </li>
                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/manage');?>">查询</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

    <div class="content pure-u-1 pure-u-md-3-4">
            <div class="posts">
                <h1 class="content-subhead">hello</h1>
                <section class="post">
                    <header class="post-header">
                        <h2 class="post-title">学生管理系统后台</h2>
                    </header>

                    <div class="post-description">
                        <p>
                          <form action="<?php echo U('Manage/student_query');?>" method="post">
                           <?php if(session('username')): ?>注意以下项每次只输入一项就可进行查询<br>
                              
                              请输入你想查询的学号<input type="text" name="sno"></input><br>
                              
                              请输入你想查询的班级,按学号由小到大显示<input type="text" name="class"></input><br>
                              
                              请输入你想查询的院系,按学号由小到大显示<input type="text" name="dept"></input><br>
                              
                              请输入教师工号<input type="text" name="tno"></input><br>
                              
                              请输入你想查询的课程号,按分数排名显示<input type="text" name="categoryid"></input><br>
                              查看课程号 <input type="text" name="category2">的分数段从
                               <input type="text" name="low_score"></input>
                              分到<input type="text" name="high_score">  </input> 分的情况<br>

                              <br>  
                              查看班级号 <input type="text" name="class2">
                              的课程号 <input type="text" name="category3">
                              从 <input type="text" name="low"></input>分到<input type="text" name="high">  </input> 分<br>
                    
                           <?php else: ?>
                              请输入你的学号<input type="text" name="sno"></input><?php endif; ?>
                           <input type="submit" class="pure-button" value="提交查询"></input>
                           </form>   
                        </p>
                    </div>
                </section>
            </div>

            <div class="footer">
                <div class="pure-menu pure-menu-horizontal">
                    <ul>
                        <li class="pure-menu-item"><a href="" class="pure-menu-link">About</a></li>
                        <li class="pure-menu-item"><a href="" class="pure-menu-link">Twitter</a></li>
                        <li class="pure-menu-item"><a href="http://github.com/yahoo/pure/" class="pure-menu-link">GitHub</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

 
  </body>