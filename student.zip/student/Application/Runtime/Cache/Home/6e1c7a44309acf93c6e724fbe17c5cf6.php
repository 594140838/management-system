<?php if (!defined('THINK_PATH')) exit();?> <head>

<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/grids-responsive-min.css">
<link rel="stylesheet" href="/student/Public/<?php echo (MODULE_NAME); ?>/Css/blog.css">
 </head>
 <body>
 <div id="layout" class="pure-g">
    <div class="sidebar pure-u-1 pure-u-md-1-4">
        <div class="header">
            <h1 class="brand-title">朱星滔 的 学生管理系统</h1>
            <h2 class="brand-tagline">Welcome <?php echo session('username');?> to here</h2>

            <nav class="nav">
                <ul class="nav-list">
                    
                    
                    <?php if((session('username'))): ?><li class="nav-item">
                            <a class="pure-button" href="<?php echo U('Index/logout');?>">注销</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="pure-button" href="<?php echo U('Index/login');?>">登陆</a>
                        </li><?php endif; ?>

                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/register');?>">注册</a>
                    </li>
                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/index');?>">首页</a>
                    </li>
                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/manage');?>">查询</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

    <div class="content pure-u-1 pure-u-md-3-4">
            <div class="posts">
                <h1 class="content-subhead">hello</h1>
                <section class="post">
                    <header class="post-header">
                        <h2 class="post-title">学生管理系统后台</h2>
                    </header>

                    <div class="post-description">
                        <p>
                         修改信息页面
          
                       
                          <table class="pure-table pure-table-bordered ">
                              <form action="<?php echo U('Manage/teacher_update');?>" method="post">
                              <tr> 
                                <td>教师姓名</td>     
                                <td> <input type="text"  name ="name"  value="<?php echo ($teacher["name"]); ?>"></td>
                              </tr>  
    
                              <tr> 
                                <td>课程名</td>
                                <td> <input  type="text"  name="class"  value="<?php echo ($teacher["class"]); ?>"> </td>   
                              </tr> 
                              <tr> 
                                <td>课程号</td>
                                <td> <input  type="text"  name="classid"  value="<?php echo ($teacher["classid"]); ?>"></td>
                              </tr> 
                              <tr>
                                <td>教师编号</td>
                                <td> <input  type="text"  name="tno" value="<?php echo ($teacher["tno"]); ?>"></td>   
                              </tr>    
                              <tr> 
                                <td>编辑</td>
                                <td> <input type="submit" class="pure-button" value="点击确认修改"></input></td>
                              </tr>             
                              </form>  
                      
                              <tr> 
                              <td>删除</td>
                              <form action="<?php echo U('Manage/teacher_delete');?>" method="post">
                                     <input type="hidden" name ="tno"  value="<?php echo ($teacher["tno"]); ?>"></td>
                                     <td> <input type="submit" class="pure-button" value="删除该条记录"/></td>
                              </form>
                             </tr>  
                            </table>
                        </p>
                    </div>
                </section>
            </div>

        </div>
    </div>
</div>

 
  </body>