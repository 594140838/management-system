<?php if (!defined('THINK_PATH')) exit();?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="A layout example that shows off a blog page with a list of posts.">

    <title>management system</title>

    


<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/grids-responsive-min.css">
<link rel="stylesheet" href="/student/Public/<?php echo (MODULE_NAME); ?>/Css/blog.css">


   

</head>
<body>







<div id="layout" class="pure-g">
    <div class="sidebar pure-u-1 pure-u-md-1-4">
        <div class="header">
            <h1 class="brand-title">朱星滔 的 学生管理系统</h1>
            <h2 class="brand-tagline">Welcome <?php echo session('username');?> to here</h2>

            <nav class="nav">
                <ul class="nav-list">
                    
                    
                    <?php if((session('username'))): ?><li class="nav-item">
                            <a class="pure-button" href="<?php echo U('Index/logout');?>">注销</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="pure-button" href="<?php echo U('Index/login');?>">登陆</a>
                        </li><?php endif; ?>

                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/register');?>">注册</a>
                    </li>
                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/index');?>">首页</a>
                    </li>
                    <li class="nav-item">
                        <a class="pure-button" href="<?php echo U('Index/manage');?>">查询</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

    <div class="content pure-u-1 pure-u-md-3-4">
            <!-- A wrapper for all the blog posts -->
            <div class="posts">
                <h1 class="content-subhead">hello</h1>

                <!-- A single blog post -->
                <section class="post">
                    <header class="post-header">
                        <h2 class="post-title">学生管理系统后台</h2>

                        <p class="post-meta">
                            By <a href="#" class="post-author">朱星滔</a> 
                        </p>
                    </header>

                    <div class="post-description">
                        <p>
                             删除成功
  
                         <hr>
                          <a href="<?php echo U('Manage/management');?>"> 回到管理页面</a>
                        </p>
                    </div>
                </section>
            </div>
  

            <div class="footer">
                <div class="pure-menu pure-menu-horizontal">
                    <ul>
                        <li class="pure-menu-item"><a href="http://purecss.io/" class="pure-menu-link">About</a></li>
                        <li class="pure-menu-item"><a href="http://twitter.com/yuilibrary/" class="pure-menu-link">Twitter</a></li>
                        <li class="pure-menu-item"><a href="http://github.com/yahoo/pure/" class="pure-menu-link">GitHub</a></li>
                    </ul>
                </div>
            </div>

    </div>
</div>


</body>
</html>