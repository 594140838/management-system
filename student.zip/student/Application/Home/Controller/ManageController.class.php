<?php
namespace Home\Controller;
use Think\Controller;
class ManageController extends Controller {
  
 
    public function student_query($sno){
      
        if (!empty($_POST['sno'])){
            $studb = M('student');
            $student = $studb->where("sno='".$sno."'")->order('sno')->select();
        }
        else if(!empty($_POST['class'])){
            
            $studb = M('student');
            $student = $studb->where("class='".I('class')."'")->order('sno')->select();
           
        } 
        else if (!empty($_POST['dept'])){
           $studb = M('student');
           $student = $studb->where("dept='".I('dept')."'")->order('sno')->select();
        }
        else if (!empty($_POST['tno'])){
           $teacherdb = M('teacher');
           $class = $teacherdb->where('tno='.$tno)->getField('class');
           $studb = M('student');
           $student = $studb->where("class='".$class."'")->order('sno')->select();
        } 
        else if (isset($_POST['low_score'])&&isset($_POST['high_score'])&&I('category2')){
            $studb = M('student');
            $student = $studb->where("grade>='".I('low_score')."'&&grade<='".I('high_score')."'&&categoryid=".I('category2'))->order('grade')->select();
        }
        else if (isset($_POST['low'])&&isset($_POST['class2'])&&isset($_POST['category3'])&&I('high')){
            $studb = M('student');
            $student = $studb->where("grade>='".I('low')."'&&grade<=".I('high').'&&class='
                                      .I('class2')."&&categoryid=".I('category3'))
                             ->order('grade')->select();
        }
        else if ($_POST['categoryid']>0){
           $studb = M('student');
           $student = $studb->where("categoryid='".I('categoryid')."'")->order('grade desc')->select();
        }
        if ($student) $this->assign('student',$student);
        $this->display();
    }

    public function teacher_query(){
        $teacherdb = M('teacher');
        $teacher = $teacherdb->select();
        $this->assign('teacher',$teacher);
        $this->display();
    }
    public function student_update(){ 
        $studb = M('student');
        if (I('post.sno')){
           $data['sno'] = I('sno');
           $data['name'] = I('name');
           $data['grade'] = I('grade');
           $data['dept'] = I('dept');
           $data['class'] = I('class');
           $info = $studb->where('sno='.I('sno'))->save($data);
           if ($info) { $this->success('修改成功',U('Index/manage'));}
           else $this->error('修改失败',U('Index/manage'));
        }
        else {
            $data = $studb->where("sno=".I('sno'))->find();
            $this->assign('student',$data);
            $this->display();
        }
    }

   public function student_delete(){
     $studb=M('student');
     $studb->where('sno='.I('sno'))->delete();
     $this->display(); 
   }

   public function student_insert(){
     if (!$_POST) $this->display();
     else {
          $studb=M('student');
          $data['sno'] = I('sno');
          $data['name'] = I('name');
          $data['grade'] = I('grade');
          $data['category'] = I('category');
          $data['categoryid'] = I('categoryid');
          $data['dept'] = I('dept');
          $data['class'] = I('class');
          $info=$studb->add($data);
          if ($info) { $this->success('增添学生成功',U('Index/manage'));}
          else $this->error('操作失败了',U('Index/manage'));
     }   
     
   } 


   public function management(){
    if (session('username')==='root'){
        $teacherdb = M('teacher');
        $teacher = $teacherdb->order('tno')->select();
        $this->assign('teacher',$teacher);
        $this->display();
    }
    else {
      $this->error('只有管理员才能进入管理界面');
    }
   }

   public function teacher_insert(){
    if (!$_POST) $this->display();
     else {
          $tb=M('teacher');
          $data['tno'] = I('tno');
          $data['name'] = I('name');
          $data['class'] = I('class');
          $data['classid'] = I('classid');
          $info=$tb->add($data);
          if ($info) { $this->success('增添老师成功',U('manage/management'));}
          else $this->error('操作失败了',U('manage/management'));
     }   
   }
   public function teacher_delete(){
     $studb=M('teacher');
     $studb->where('tno='.I('tno'))->delete();
     $this->display(); 
   }
   public function teacher_update(){ 
        $tb = M('teacher');
        if (I('post.tno')){
           $data['tno'] = I('tno');
           $data['name'] = I('name');
           $data['classid'] = I('classid');
           $data['class'] = I('class');
           $info = $tb->where('tno='.I('tno'))->save($data);
           if ($info) { $this->success('修改成功',U('Manage/management'));}
           else {
             $info = $tb->where("name='".I('name')."'")->save($data);
             if ($info) { $this->success('修改成功',U('Manage/management'));}
             else $this->error('修改失败',U('Manage/management'));
           }
        }
        else {
            $data = $tb->where("tno=".I('tno'))->find();
            $this->assign('teacher',$data);
            $this->display();
        }
    }
}