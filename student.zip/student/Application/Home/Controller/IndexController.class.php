<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
    	$this->display();
    }
    public function register(){
    	if (!$_POST){
     	 $this->display();
     	}
     	else {
     		if (I('post.password') != I('post.password2')) $this -> error('两次密码必须一致',U('Index/register'));
     		$user = M('user');
     		
     		//检测是否已存在相同用户名,这里没有采用前台ajax无刷新验证的方式，以后会完善
     		$username = I('username');
     		$info = $user -> where("username='".$username."'") -> find();
     		if ($info != 0) { $this -> error('已有人使用了该用户名，请换一个',U('Index/register'));}
     		//检测是否已存在相同用户账号
     		$userid = I('userid');
			$info = $user -> where("userid='".$userid."'") -> find();
     		if ($info) { $this -> error('已有人使用了该账号，请换一个',U('Index/register'));}
     		//获取用户注册的数据
     		$data = array(
 				"username"=>$username,
  				"userid"=>$userid,
 				"password"=>I('password','','md5'),
  				"email"=> I('email')
     		);
     		
     		$info = $user->add($data);
     		if ($info) { $this->success('注册成功',U('Index/login'));}
     		else $this->error('注册失败,请重新注册');
   		}
    }
     public function login(){
     	if (!$_POST){
     		$this->display();
     	}
     	else {
     		$user = M('user');
     		$userid = I('userid');
     		$passwd = I('password');
     		$info = $user->where("userid='".$userid."'")->find();
     		if ($info){
     			if (md5($passwd)===$info['password'])
     			{
     			  session('username',$info['username']);
     			  $this->success('登陆成功,跳转到首页',U('Index/index'));
     			}
               else $this->error('密码错误,请重新登陆',U('Index/login'));
     		}
            else $this->error('该用户尚未注册,请进行注册',U('Index/register'));
     	}
     	
    }

    public function logout(){
       session('[destroy]');	
       $this->redirect('Index/index');
    }

    public function manage(){
     $this->display();
    }
}